#!/usr/bin/env python3
"""Immutable CPU-only capability evaluation adapter for P1/P2.

Reads existing P2 D_dev predictions. Does not load or train a model.
Writes one immutable sidecar per run_id.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

CAPABILITIES = (
    "addition",
    "subtraction",
    "multiplication",
    "division",
    "percentage",
    "fraction",
    "ratio",
)

REQUIRED_OUTPUTS = (
    "capability_metrics.csv",
    "capability_metrics.jsonl",
    "prediction_coverage_report.json",
    "checkpoint_lineage.json",
    "input_fingerprint.json",
    "student_capability_evaluation_manifest.json",
)

EXPECTED_SUPPORT = {
    "addition": 30,
    "subtraction": 51,
    "multiplication": 73,
    "division": 47,
    "fraction": 31,
    "percentage": 29,
    "ratio": 30,
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def hash_path(path: Path) -> str:
    path = path.resolve()

    if path.is_file():
        return sha256_file(path)

    if not path.is_dir():
        raise FileNotFoundError(f"Input does not exist: {path}")

    files = sorted(p for p in path.rglob("*") if p.is_file())
    if not files:
        raise ValueError(f"Checkpoint directory is empty: {path}")

    digest = hashlib.sha256()
    for file_path in files:
        relative = file_path.relative_to(path).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(sha256_file(file_path).encode("ascii"))
        digest.update(b"\n")

    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []

    with path.open("r", encoding="utf-8-sig") as stream:
        for line_no, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"Invalid JSONL at {path}:{line_no}: {exc}"
                ) from exc

            if not isinstance(row, dict):
                raise ValueError(
                    f"Expected JSON object at {path}:{line_no}"
                )
            rows.append(row)

    return rows


def read_id_file(path: Path) -> set[str]:
    values = [
        line.strip()
        for line in path.read_text(encoding="utf-8-sig").splitlines()
        if line.strip()
    ]

    if len(values) != len(set(values)):
        raise ValueError(f"Duplicate IDs in {path}")

    return set(values)


def wilson_interval(
    correct: int,
    support: int,
    z: float = 1.959963984540054,
) -> tuple[float | None, float | None]:
    if support <= 0:
        return None, None

    p = correct / support
    z2 = z * z
    denominator = 1.0 + z2 / support
    center = (p + z2 / (2.0 * support)) / denominator
    margin = (
        z
        * (
            p * (1.0 - p) / support
            + z2 / (4.0 * support * support)
        ) ** 0.5
        / denominator
    )

    return max(0.0, center - margin), min(1.0, center + margin)


def strict_correct(row: dict[str, Any]) -> bool:
    """P2 primary strict metric: only status == 'valid' is correct."""
    status = row.get("status")

    if status not in {"valid", "invalid_answer", "invalid_format"}:
        raise ValueError(
            "Prediction must contain a recognized P2 status; "
            f"got status={status!r}, problem_id={row.get('problem_id')!r}"
        )

    return status == "valid"


def load_approved_gold(
    gold_path: Path,
    approval_path: Path,
    dev_ids: set[str],
) -> dict[str, dict[str, Any]]:
    gold_rows = read_jsonl(gold_path)

    if len(gold_rows) != 85:
        raise ValueError(
            f"Expected exactly 85 Gold rows; found {len(gold_rows)}"
        )

    gold_by_id: dict[str, dict[str, Any]] = {}

    for row in gold_rows:
        problem_id = str(row.get("problem_id", "")).strip()
        if not problem_id:
            raise ValueError("Gold row missing problem_id")
        if problem_id in gold_by_id:
            raise ValueError(f"Duplicate Gold problem_id: {problem_id}")

        labels = row.get("capabilities_manual")
        if not isinstance(labels, list) or not labels:
            raise ValueError(
                f"Gold capability labels missing/invalid: {problem_id}"
            )

        unknown = set(labels) - set(CAPABILITIES)
        if unknown:
            raise ValueError(
                f"Unknown capabilities for {problem_id}: {sorted(unknown)}"
            )

        gold_by_id[problem_id] = row

    gold_ids = set(gold_by_id)

    if len(gold_ids) != 85:
        raise ValueError("Gold IDs are not 85 unique IDs")

    if not gold_ids.issubset(dev_ids):
        outside = sorted(gold_ids - dev_ids)
        raise ValueError(
            f"Gold IDs outside D_dev: {outside[:10]}"
        )

    approval_by_id: dict[str, dict[str, str]] = {}

    with approval_path.open(
        "r", encoding="utf-8-sig", newline=""
    ) as stream:
        reader = csv.DictReader(stream)

        required_columns = {
            "problem_id",
            "review_status",
            "human_approval",
        }
        actual_columns = set(reader.fieldnames or [])
        missing_columns = required_columns - actual_columns

        if missing_columns:
            raise ValueError(
                f"Approval CSV missing columns: {sorted(missing_columns)}"
            )

        for row in reader:
            problem_id = str(row.get("problem_id", "")).strip()
            if not problem_id:
                raise ValueError("Approval CSV contains empty problem_id")
            if problem_id in approval_by_id:
                raise ValueError(
                    f"Duplicate approval problem_id: {problem_id}"
                )
            approval_by_id[problem_id] = row

    approval_ids = set(approval_by_id)

    if approval_ids != gold_ids:
        missing = sorted(gold_ids - approval_ids)
        extra = sorted(approval_ids - gold_ids)
        raise ValueError(
            "Approval/Gold ID set mismatch: "
            f"missing_approval={missing[:10]}, "
            f"extra_approval={extra[:10]}"
        )

    for problem_id, row in approval_by_id.items():
        review_status = str(row.get("review_status", "")).strip()
        human_approval = str(row.get("human_approval", "")).strip()

        approved_review_statuses = {
            "APPROVED_NO_LABEL_CHANGE",
            "APPROVED_WITH_SOURCE_CLARIFICATION",
        }

        if review_status not in approved_review_statuses:
            raise ValueError(
                f"Gold review status is not approved: "
                f"{problem_id}={review_status!r}"
            )

        if not human_approval.startswith("APPROVED_BY_USER_"):
            raise ValueError(
                f"Gold lacks explicit user approval: "
                f"{problem_id}={human_approval!r}"
            )

    return gold_by_id


def build_input_hashes(args: argparse.Namespace) -> dict[str, str]:
    input_paths = {
        "checkpoint": Path(args.checkpoint),
        "dev_predictions": Path(args.dev_predictions),
        "gold_manifest": Path(args.gold_manifest),
        "gold_labels": Path(args.gold_labels),
        "approval_csv": Path(args.approval_csv),
        "dev_ids": Path(args.dev_ids),
        "config": Path(args.config),
    }

    optional_paths = {
        "train_set": args.train_set,
        "selection_log": args.selection_log,
        "train_log": args.train_log,
        "checkpoint_log": args.checkpoint_log,
    }

    for name, value in optional_paths.items():
        if value:
            input_paths[name] = Path(value)

    hashes: dict[str, str] = {}
    for name, path in input_paths.items():
        if not path.exists():
            raise FileNotFoundError(f"Missing input {name}: {path}")
        hashes[name] = hash_path(path)

    return hashes


def validate_manifest_count(path: Path) -> None:
    manifest = read_json(path)

    if manifest.get("gold_version") != "vFinal":
        raise ValueError(
            "Expected Gold manifest gold_version='vFinal'"
        )

    if manifest.get("supplement_count") != 85:
        raise ValueError(
            "Gold manifest supplement_count must equal 85"
        )


def build_sidecar(
    args: argparse.Namespace,
    stage: Path,
    input_hashes: dict[str, str],
) -> None:
    dev_ids = read_id_file(Path(args.dev_ids))

    if len(dev_ids) != 500:
        raise ValueError(
            f"Expected 500 unique D_dev IDs; found {len(dev_ids)}"
        )

    predictions = read_jsonl(Path(args.dev_predictions))
    prediction_ids = [
        str(row.get("problem_id", "")).strip()
        for row in predictions
    ]

    if any(not value for value in prediction_ids):
        raise ValueError("Prediction contains empty problem_id")

    if len(prediction_ids) != len(set(prediction_ids)):
        raise ValueError("Duplicate problem_id in D_dev predictions")

    if set(prediction_ids) != dev_ids or len(predictions) != 500:
        missing = sorted(dev_ids - set(prediction_ids))
        extra = sorted(set(prediction_ids) - dev_ids)
        raise ValueError(
            "Prediction coverage mismatch: "
            f"rows={len(predictions)}, "
            f"missing={missing[:10]}, extra={extra[:10]}"
        )

    prediction_by_id = {
        str(row["problem_id"]): row for row in predictions
    }

    # Validate status for every prediction, not only the 85 Gold rows.
    for row in predictions:
        strict_correct(row)

    validate_manifest_count(Path(args.gold_manifest))

    gold_by_id = load_approved_gold(
        Path(args.gold_labels),
        Path(args.approval_csv),
        dev_ids,
    )

    metrics: list[dict[str, Any]] = []

    for capability in CAPABILITIES:
        capability_ids = sorted(
            problem_id
            for problem_id, gold in gold_by_id.items()
            if capability in gold["capabilities_manual"]
        )

        support = len(capability_ids)
        correct = sum(
            strict_correct(prediction_by_id[problem_id])
            for problem_id in capability_ids
        )

        ci_low, ci_high = wilson_interval(correct, support)

        metrics.append({
            "run_id": args.run_id,
            "method": args.method,
            "seed": args.seed,
            "checkpoint": f"S{args.round}",
            "checkpoint_id": Path(args.checkpoint).name,
            "capability": capability,
            "n_support": support,
            "n_correct": correct,
            "n_incorrect": support - correct,
            "mastery": correct / support if support else None,
            "deficit": 1.0 - correct / support if support else None,
            "ci95_low": ci_low,
            "ci95_high": ci_high,
            "ci_method": "Wilson_95_percent",
            "strict_metric": "status_equals_valid",
            "gold_policy": "approved_85_primary",
        })

    observed_support = {
        row["capability"]: row["n_support"] for row in metrics
    }

    if observed_support != EXPECTED_SUPPORT:
        raise ValueError(
            "Gold capability support differs from the frozen expected "
            f"vector. observed={observed_support}; "
            f"expected={EXPECTED_SUPPORT}"
        )

    with (stage / "capability_metrics.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=list(metrics[0].keys()),
        )
        writer.writeheader()
        writer.writerows(metrics)

    with (stage / "capability_metrics.jsonl").open(
        "w", encoding="utf-8"
    ) as stream:
        for row in metrics:
            stream.write(
                json.dumps(row, ensure_ascii=False) + "\n"
            )

    coverage = {
        "status": "PASS",
        "split": "D_dev",
        "expected_dev_ids": 500,
        "prediction_records": len(predictions),
        "prediction_unique_ids": len(set(prediction_ids)),
        "gold_records": len(gold_by_id),
        "gold_unique_ids": len(gold_by_id),
        "gold_matched_prediction_ids": len(
            set(gold_by_id) & set(prediction_ids)
        ),
        "missing_prediction_ids": [],
        "gold_policy": "approved_85_primary",
        "strict_correctness_policy": "status == valid",
        "lenient_correct_excluded": True,
        "capability_support": observed_support,
    }

    (stage / "prediction_coverage_report.json").write_text(
        json.dumps(coverage, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    lineage = {
        "run_id": args.run_id,
        "method": args.method,
        "seed": args.seed,
        "round": args.round,
        "checkpoint_id": Path(args.checkpoint).name,
        "checkpoint_path": str(Path(args.checkpoint)),
        "checkpoint_sha256": input_hashes["checkpoint"],
        "shared_checkpoint_group": args.shared_checkpoint_group,
        "train_set": args.train_set,
        "selection_log": args.selection_log,
        "train_log": args.train_log,
        "checkpoint_log": args.checkpoint_log,
        "config_sha256": input_hashes["config"],
        "prediction_sha256": input_hashes["dev_predictions"],
        "gold_manifest_sha256": input_hashes["gold_manifest"],
        "gold_labels_sha256": input_hashes["gold_labels"],
        "approval_csv_sha256": input_hashes["approval_csv"],
        "dev_ids_sha256": input_hashes["dev_ids"],
    }

    (stage / "checkpoint_lineage.json").write_text(
        json.dumps(lineage, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    fingerprint = hashlib.sha256(
        json.dumps(
            input_hashes,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()

    (stage / "input_fingerprint.json").write_text(
        json.dumps({
            "fingerprint": fingerprint,
            "inputs": input_hashes,
        }, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    manifest = {
        "schema_version": "p1p2.capability-manifest.v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "run_id": args.run_id,
        "method": args.method,
        "seed": args.seed,
        "round": args.round,
        "checkpoint": f"S{args.round}",
        "gold_policy": "approved_85_primary",
        "strict_metric": "status == valid",
        "capabilities": list(CAPABILITIES),
        "n_capability_rows": len(metrics),
        "input_hashes": input_hashes,
        "outputs": {},
        "overwrite_policy": "immutable_exact_fingerprint_reuse_only",
    }

    for name in REQUIRED_OUTPUTS:
        if name == "student_capability_evaluation_manifest.json":
            continue

        output_path = stage / name
        manifest["outputs"][name] = {
            "sha256": sha256_file(output_path),
            "size_bytes": output_path.stat().st_size,
        }

    (stage / "student_capability_evaluation_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def verify_existing_sidecar(
    out_dir: Path,
    input_hashes: dict[str, str],
) -> None:
    manifest_path = (
        out_dir / "student_capability_evaluation_manifest.json"
    )

    if not manifest_path.is_file():
        raise RuntimeError(
            "EXISTING_PARTIAL_SIDECAR: manifest missing; "
            "do not overwrite or auto-delete this directory"
        )

    manifest = read_json(manifest_path)

    if manifest.get("input_hashes") != input_hashes:
        raise RuntimeError(
            "INPUT_FINGERPRINT_MISMATCH: sidecar is immutable"
        )

    outputs = manifest.get("outputs", {})
    expected_names = set(REQUIRED_OUTPUTS) - {
        "student_capability_evaluation_manifest.json"
    }

    if set(outputs) != expected_names:
        raise RuntimeError("Existing sidecar output inventory mismatch")

    for name, metadata in outputs.items():
        path = out_dir / name

        if not path.is_file():
            raise RuntimeError(f"Existing output missing: {path}")

        if sha256_file(path) != metadata.get("sha256"):
            raise RuntimeError(f"Existing output hash mismatch: {path}")

    print(f"REUSE: PASS {out_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="CPU-only P1/P2 capability sidecar evaluator"
    )

    parser.add_argument("--run-id", required=True)
    parser.add_argument(
        "--method",
        required=True,
        choices=["SHARED", "B2", "B3", "B4", "B5"],
    )
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument(
        "--round",
        required=True,
        type=int,
        choices=[0, 1, 2, 3],
    )

    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--dev-predictions", required=True)
    parser.add_argument("--gold-manifest", required=True)
    parser.add_argument("--gold-labels", required=True)
    parser.add_argument("--approval-csv", required=True)
    parser.add_argument("--dev-ids", required=True)
    parser.add_argument("--config", required=True)

    parser.add_argument("--train-set")
    parser.add_argument("--selection-log")
    parser.add_argument("--train-log")
    parser.add_argument("--checkpoint-log")
    parser.add_argument("--shared-checkpoint-group")
    parser.add_argument(
        "--out-root",
        default="reports/capability",
    )

    args = parser.parse_args()

    expected_run_id = (
        "SHARED_seed0_S0"
        if args.method == "SHARED"
        else f"{args.method}_seed{args.seed}_S{args.round}"
    )

    if args.run_id != expected_run_id:
        parser.error(
            f"--run-id must be {expected_run_id!r} "
            f"for the supplied method/seed/round"
        )

    if args.method == "SHARED" and (
        args.seed != 0 or args.round != 0
    ):
        parser.error("SHARED baseline must use seed=0 and round=0")

    if args.method != "SHARED" and args.round == 0:
        parser.error("S0 is a shared baseline, not a method-specific run")

    return args



def publish_staged_directory(stage: Path, out_dir: Path) -> None:
    """Publish without overwrite; retry transient Windows permission failures."""
    retry_delays = (0.25, 0.5, 1.0, 2.0, 4.0)

    for attempt in range(len(retry_delays) + 1):
        if out_dir.exists():
            raise FileExistsError(
                "OUTPUT_COLLISION: destination already exists; "
                "refusing to overwrite: " + str(out_dir)
            )

        try:
            os.rename(stage, out_dir)
            return
        except PermissionError as exc:
            if out_dir.exists():
                raise FileExistsError(
                    "OUTPUT_COLLISION: destination appeared during "
                    "publication; refusing to overwrite: " + str(out_dir)
                ) from exc

            if attempt >= len(retry_delays):
                raise RuntimeError(
                    "PUBLICATION_FAILED_AFTER_RETRIES: "
                    f"{type(exc).__name__}: {exc}. "
                    f"Recovery staging directory preserved at: {stage}"
                ) from exc

            delay = retry_delays[attempt]
            print(
                "PUBLICATION_RETRY="
                f"{attempt + 1}/{len(retry_delays)} "
                f"DELAY_SECONDS={delay}"
            )
            time.sleep(delay)


def main() -> None:
    args = parse_args()

    input_hashes = build_input_hashes(args)
    out_dir = Path(args.out_root) / args.run_id

    if out_dir.exists():
        verify_existing_sidecar(out_dir, input_hashes)
        return

    out_dir.parent.mkdir(parents=True, exist_ok=True)

    stage = Path(tempfile.mkdtemp(
        prefix=f".{args.run_id}.staging.",
        dir=out_dir.parent,
    ))

    try:
        build_sidecar(args, stage, input_hashes)
        publish_staged_directory(stage, out_dir)
    except Exception as exc:
        if stage.exists():
            print(f"RECOVERY_STAGING_PRESERVED={stage}")
            print(f"RECOVERY_ERROR={type(exc).__name__}: {exc}")
        raise

    print(f"CAPABILITY_EVAL: PASS {out_dir}")


if __name__ == "__main__":
    main()
